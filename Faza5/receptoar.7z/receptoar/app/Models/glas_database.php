<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Klasa sa implementacijama funkcija za rad sa tabelom Glas
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class Glas_Database extends Model {
    protected $table      = 'glas';
    
    protected $primaryKey = 'ID_objava,ID_korisnik';

    protected $returnType     = 'object';

    protected $allowedFields = ['ID_objava', 'ID_korisnik', 'Glasao'];
    
    /**
     * Funkcija za dohvatanje glasova
     * @return void
     */
    public function getGlasove($idKor){
        return $this->where('ID_korisnik',$idKor)->findAll();
    }
    
    /**
     * Funkcija za dodavanje glasa
     * @return void
     */
    public function dajGlas($idObj) {
    
        $this->session= \Config\Services::session();
        $korisnik=$this->session->get('korisnik');
        if ($korisnik!=null) {
            $idKor = $korisnik[0]->ID_korisnik;

            if($this->where('ID_korisnik',$idKor)->where('ID_objava',$idObj)->findAll()){
                return false;
            }
            else {
                $data=[
                    'ID_objava'=>$idObj,
                    'ID_korisnik'=>$idKor,
                    'Glasao'=>1
                ];
                $this->insert($data);
                return true;
            }
        }
    }
    
    
}