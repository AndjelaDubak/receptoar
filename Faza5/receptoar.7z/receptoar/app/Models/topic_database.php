<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Klasa sa implementacijama funkcija za rad sa tabelom Tema
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class Topic_Database extends Model {
    protected $table      = 'tema';
    
    protected $primaryKey = 'ID_tema';

    protected $returnType     = 'object';

    protected $allowedFields = ['Naziv', 'Aktuelna', 'Vreme'];   
    
    /**
     * Funkcija za dohvatanje aktuelne teme
     * @return Tema
     */
    public function current_topic() {
        $top = $this->where('Aktuelna',2)->findAll();
        return $top[0]->ID_tema;
    }
}