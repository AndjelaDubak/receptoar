<?php

namespace App\Models;
               
use CodeIgniter\Model;

/**
 * Klasa sa implementacijama funkcija za rad sa tabelom Komentar
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class Komentar_Database extends Model {
    protected $table      = 'komentar';
    
    protected $primaryKey = 'ID_objava,ID_komentar';

    protected $returnType     = 'object';

    protected $allowedFields = ['ID_objava', 'ID_komentar', 'Tekst','Broj_lajkova'];
    
    /**
     * Funkcija za dohvatanje komentara
     * @return Komentar
     */
    public function getKomentare($idObj){
        return $this->where('ID_objava',$idObj)->findAll();
    }
    
    /**
     * Funkcija za dodavanje komentara
     * @return void
     */
    public function dodajKomentar($id, $text) {
        
        $obj = [
            'ID_objava' => $id,
            'Tekst' => $text,
            'Broj_lajkova' => 0
        ];
        
        $this->insert($obj);
    }
    
     public function getIDkomentara($idObj){
        $niz2=array();
        $komentari=$this->where('ID_objava',$idObj)->findAll();
        
        foreach($komentari as $kom){
            array_push($niz2,$kom->ID_komentar);
        }
        
        return $niz2;
    }
    
    public function obrisiKomentar($idKom){
        $this->where('ID_komentar',$idKom)->delete();
    }
    
    public function dodajLajk($idKom){
        $kom = $this->where('ID_komentar',$idKom)->findAll();
        print_r($kom);
        if($kom!=null){
        $kom[0]->Broj_lajkova=$kom[0]->Broj_lajkova+1;
        $this->update($idKom,$kom[0]);
        }
    }
    
}