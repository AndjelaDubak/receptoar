<?php

namespace App\Models;

use CodeIgniter\Model;

/**
 * Klasa sa implementacijama funkcija za rad sa tabelom Korisnik
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class Login_Database extends Model {
    protected $table      = 'korisnik';
    
    protected $primaryKey = 'ID_korisnik';

    protected $returnType     = 'object';

    protected $allowedFields = ['Ime', 'Prezime', 'Email', 'Korisnicko_ime', 'Lozinka', 'Broj pobeda', 'Kategorija_korisnika'];
    
    /**
     * Funkcija za dohvatanje korisnika
     * @return Korisnik
     */
    public function getKorisnik($id){
      return $this->where('ID_korisnik',$id)->findAll();
    }
    
    /**
     * Funkcija za dohvatanje svih korisnika
     * @return Korisnici[]
     */
    public function getSveKorisnike() {
        return $this->where('Kategorija_korisnika', 'K')->findAll();
    }
    
    /**
     * Funkcija za dohvatanje svih moderatora
     * @return Moderatori[]
     */
    public function getSveModeratore() {
        return $this->where('Kategorija_korisnika', 'M')->findAll();
    }
    
    /**
     * Funkcija za promenu kategorije korisnika
     * @return void
     */
    public function promeniKategoriju($korIme) {
        $korisnik = $this->where('Korisnicko_ime', $korIme)->findAll();
        if($korisnik[0]->Kategorija_korisnika == 'K') {
            $korisnik[0]->Kategorija_korisnika = 'M';
        }
        else if($korisnik[0]->Kategorija_korisnika == 'M') {
            $korisnik[0]->Kategorija_korisnika = 'K';
        }
        
        $this->update($korisnik[0]->ID_korisnik, $korisnik[0]);
    }
    
    /**
     * Funkcija za brisanje korisnika
     * @return void
     */
    public function obrisiKorisnika($korIme) {
        $korisnik = $this->where('Korisnicko_ime', $korIme)->findAll();
        $this->where('ID_korisnik', $korisnik[0]->ID_korisnik)->delete();
    }
}