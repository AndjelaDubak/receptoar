<?php

namespace App\Models;
               
use CodeIgniter\Model;

class Lajk_Database extends Model {
    protected $table      = 'lajk';
    protected $primaryKey = 'ID_korisnik,ID_komentar';

   // protected $useAutoIncrement = true;

    protected $returnType     = 'object';
    //protected $useSoftDeletes = true;

    protected $allowedFields = ['ID_korisnik', 'ID_komentar', 'Lajkovao'];

    //protected $useTimestamps = false;
    //protected $createdField  = 'created_at';
    //protected $updatedField  = 'updated_at';
    //protected $deletedField  = 'deleted_at';

    //protected $validationRules    = [];
    //protected $validationMessages = [];
    //protected $skipValidation     = false;
    
    public function dodajLajk($idKom) {
        $this->session= \Config\Services::session();
        $korisnik=$this->session->get('korisnik');
        $idKor=$korisnik[0]->ID_korisnik;
        
        $obj = [
            'ID_korisnik' => $idKor,
            'ID_komentar' => $idKom,
            'Lajkovao' => 1
        ];
        
        $this->insert($obj); 
    }
    
    public function getLajkovaneKomentare($idKorisnik){        
        $glasovi=$this->where('ID_korisnik',$idKorisnik)->findAll();
        return $glasovi;
    }
    
}