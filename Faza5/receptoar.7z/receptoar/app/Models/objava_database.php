<?php

namespace App\Models;

use CodeIgniter\Model;
use App\Models\topic_database;

/**
 * Klasa sa implementacijama funkcija za rad sa tabelom Objava
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class Objava_Database extends Model {
    protected $table      = 'objava';
    
    protected $primaryKey = 'ID_objava';

    protected $returnType     = 'object';

    protected $allowedFields = ['ID_korisnik','ID_tema','Naziv', 'Fotografija', 'Opis', 'Pobednicka', 'Sastojci', 'Vreme', 'Kategorija_korisnika', 'Broj_glasova'];    
    
    /**
     * Funkcija za dodavanje recepta
     * @return void
     */
    public function insertImage($filepath, $korisnik, $naziv, $opis, $sastojci) {
        print_r($korisnik);
        $topicDatabase = new Topic_Database();
        $date = date("Y/m/d H:i:sa", time());
        $tema = $topicDatabase->current_topic();
        $post = array(
            'ID_korisnik' => $korisnik[0]->ID_korisnik,
            'ID_tema' => $tema,
            'Naziv' => $naziv,
            'Fotografija' => $filepath,
            'Opis' => $opis,
            'Broj_glasova' => 0,
            'Pobednicka' => 0,
            'Sastojci' => $sastojci,
            'Vreme' => $date,
            'Broj_komentara' => 0);
        //print_r($post);
        $this->insert($post);
    }
    
    /**
     * Funkcija za dohvatanje objave
     * @return Objava
     */
    public function getObjave(){
        $topicDatabase=new Topic_Database();
        $tema=$topicDatabase->current_topic();
        return $this->where('ID_tema',$tema)->findAll();
    }
    
    /**
     * Funkcija za promenu objave
     * @return void
     */
    public function updateObjava($id){
        if($id!=null){
  
        $obj= $this->where('ID_objava',$id)->findAll();
        //print_r($obj[0]);
        if($obj!=null){
            $obj[0]->Broj_glasova=$obj[0]->Broj_glasova+1;
            //print_r($obj[0]->Broj_glasova);
            $this->update($id,$obj[0]);
            }
        }
    }
    
    /**
     * Funkcija za dohvatanje sortiranih objava po glasovima
     * @return Objave[]
     */
    public function getSortiraneGlas() {
        $topicDatabase=new Topic_Database();
        $tema=$topicDatabase->current_topic();
        return $this->where('ID_tema',$tema)->orderBy('Broj_glasova', 'DESC')->findAll();
    }
    
    /**
     * Funkcija za dohvatanje sortiranih objava po vremenu
     * @return Objave[]
     */
    public function getSortiraneVreme() {
        $topicDatabase=new Topic_Database();
        $tema=$topicDatabase->current_topic();
        return $this->where('ID_tema',$tema)->orderBy('Vreme', 'DESC')->findAll();
    }
    
    /**
     * Funkcija za dohvatanje pobednickih recepata
     * @return Objave[]
     */
    public function getPobednicke(){
        return $this->where('Pobednicka',1)->findAll();
    }
    
    public function povecajBrojKomentara($id){
        $obj= $this->where('ID_objava',$id)->findAll();
        if($obj!=null){
            $obj[0]->Broj_komentara=$obj[0]->Broj_komentara+1;
            $this->update($id,$obj[0]);
        }
    }
    
    public  function getObjava($idObj){
        $obj= $this->where('ID_objava',$idObj)->findAll();
        return  $obj[0];
    }
}
