<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptoar</title>
    <link type="image/png" href="<?php echo base_url(); ?>/img/logo.png" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/dodatni.css">
</head>
</html>
    <body>
        <div class="backgroundTopic">
            <div id="login">
                <div class="login-form-container" id="login-form">
                    <div class="login-form-content">
                        <div class="login-form-header">
                            <div class="logo">
                                <img src="<?php echo base_url(); ?>/img/logo.png" height="80" width="100">
                            </div>
                            
                            <h3 id="pr">Postavljanje recepta</h3>
                        </div>
                        <font color='red'>
                            <?php
                                if (isset($messages['message'])) {
                                    echo $messages['message'];
                                    unset($messages['message']);
                                }
                                if (isset($messages['name'])) {
                                    echo "<br>-"; 
                                    echo $messages['name'];
                                    unset($messages['name']);
                                }
                                if (isset($messages['opis'])) {
                                    echo "<br>-"; 
                                    echo $messages['opis'];
                                    unset($messages['name']);
                                }
                                if (isset($messages['sastojci'])) {
                                    echo "<br>-"; 
                                    echo $messages['sastojci'];
                                    unset($messages['sastojci']);
                                }
                            ?>
                        </font>
                        <form method="post" action="<?php echo site_url("$controller/uploadPic") ?>" enctype="multipart/form-data" class="login-form">
                            <br>
                                <input type="file" name="file">
                            <div class="input-container" id="ime">
                                <input type="text" class="input"  name="name" placeholder="Naziv recepta">
                            </div>
                            <div class="input-container" id="ime">
                               <textarea id="review" name="opis" rows="4" cols="50" placeholder="Opis recepta"></textarea>
                            </div>
                            <div class="input-container" id="ime">
                               <textarea id="w3rew" name="sastojci" rows="4" cols="50" placeholder="Sastojci"></textarea>
                            </div>
                            <input type="submit" class="button" name="login" value = "Postavi recept">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

