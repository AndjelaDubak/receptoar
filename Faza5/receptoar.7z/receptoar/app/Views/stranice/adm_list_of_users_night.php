<!--Autor: Aleksandar Dopudja 18/0118-->
<html>
    
     <?php
        $this->session= \Config\Services::session();
        $korisnik=$this->session->get('korisnik');
        if ($korisnik!=null) {
           $username = $korisnik[0]->Korisnicko_ime;
           $name = $korisnik[0]->Ime;
        } else {
           echo view('stranice/login_form');
        }
    ?>
	<head>
            <title>Receptoar</title>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <link type="image/png" href="<?php echo base_url(); ?>/img/logo1.png" rel="shortcut icon">
            <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.css">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	</head>
        <body>
            <div id="wrapper">
                <div id="headerNoc">
                    <div id="logo">
                            <center><a href="<?php echo base_url(); ?>/Administrator/index_night"><img id="logoSlika" src="<?php echo base_url(); ?>/img/logo1.png"></a></center>
                    </div>
                    <div id="name">
                        <h1>RECEPTOAR</h1>
                    </div>
                    <div id="change">
                        <table >
                            <tr>
                                <td><a href="<?php echo base_url(); ?>/Administrator/listaKorisnika"><img id="rezimN" src="<?php echo base_url(); ?>/img/dan.png"></a></td>
                            </tr>
                        </table>
                    </div>
                </div>
                    <div id="mainNoc">
                        <div class="spisakNoc">
                            <table>
                                <tr>
                                    <td>

                                    </td>
                                    <td id = "kor_ime">&nbsp;Korisničko ime&nbsp;</td>
                                    <td>

                                    </td>
                                    <td>

                                    </td>
                                </tr>
                                <?php
                                    foreach ($list as $moderator) {
                                        echo "<tr>";
                                        echo "<td>" . ' ' . "</td>";
                                        echo "<td>" . $moderator->Korisnicko_ime . "</td>";
                                        $link = base_url();
                                        echo "<td>";
                                        echo '<a href="' . $link . '/administrator/upgrade_account_night/' . $moderator->Korisnicko_ime . '">' . '<img src="' . $link . '/img/upgrade_account1.png"></a>';
                                        echo '<a href="' . $link . 'index.php/administrator/delete_account_night/' . $moderator->Korisnicko_ime . '">' . '<img src="' . $link . '/img/delete_account1.png"></a>';
                                        echo "</td>";
                                        echo "<td>" . ' ' . "</td>";
                                        echo "</tr>";
                                    }
                                ?>
                            </table>
                        </div>
                    </div>
                    <div id="menu">
                        <ul>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_change_password_night" id="sifra">&nbsp;Promena lozinke&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_regulations_night" id="pravila">&nbsp;Pravila takmičenja&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_upload_form_night" id="postavljanje">&nbsp;Postavljanje recepta&nbsp;<a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/sortiranaVremeNoc" id="hronoloski">&nbsp;Sortiraj hronološki&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/sortiranaGlasNoc"  id="glasovi">&nbsp;Sortiraj po broju glasova&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/pobednickiNoc" id="pobednici">&nbsp;Pobednički recepti&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/listaKorisnikaNoc" id="korisnici">&nbsp;Spisak korisnika&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/listaModeratoraNoc" id="korisnici">&nbsp;Spisak moderatora&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_change_topic_night" id="tema">&nbsp;Promeni temu&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/logoutNight" id="odjava">&nbsp;Odjava&nbsp;</a></li>
                            <hr>
                        </ul>
                    </div>
            </div>
	</body>
</html>


