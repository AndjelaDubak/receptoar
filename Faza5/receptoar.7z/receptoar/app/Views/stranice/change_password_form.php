<!--Autor: Andjela Dubak 18/0658-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptoar</title>
    <link type="image/png" href="<?php echo base_url(); ?>/img/logo.png" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/dodatni.css">
</head>
<body>
    <div class="background">
        <h1></h1>
    </div>
    <div id="login">
        <div class="login-form-container" id="login-form">
            <div class="login-form-content">
                <div class="login-form-header">
                        <div class="logo">
                            <a title = 'Kliknite za nocni rezim' href="<?php echo site_url("$controller/show_change_password_night") ?>"><img src="<?php echo base_url(); ?>/img/logo.png" height="80" width="100"></a>
                        </div>
                        <h3 id="pl">Promena lozinke</h3>
                </div>
                <font color='red'>
                    <?php
                        if (isset($messages['messageOld'])) {
                            echo $messages['messageOld'];
                            echo "<br>";
                            unset($messages['messageOld']);
                        }
                        if (isset($messages['message'])) {
                            echo $messages['message'];
                            unset($messages['message']);
                        }
                        if (isset($messages['old_pass'])) {
                            echo "<br>-";
                            echo $messages['old_pass'];
                            unset($messages['old_pass']);
                        }
                        if (isset($messages['new_pass'])) {
                            echo "<br>-";
                            echo $messages['new_pass'];
                            unset($messages['new_pass']);
                        }
                        if (isset($messages['new_pass_check'])) {
                            echo "<br>-";
                            echo $messages['new_pass_check'];
                            unset($messages['new_pass_check']);
                        }
                        if (isset($messages['passLen'])) {
                            echo "<br>";
                            echo $messages['passLen'];
                            unset($messages['passLen']);
                        }
                        if (isset($messages['newpasscheckLen'])) {
                            echo "<br>";
                            echo $messages['newpasscheckLen'];
                            unset($messages['newpasscheckLen']);
                        }
                        if (isset($messages['newpasswordDifferent'])) {
                            echo "<br>";
                            echo $messages['newpasswordDifferent'];
                            unset($messages['newpasswordDifferent']);
                        }
                    ?>
                </font>
                <form method="post" action="<?php echo site_url("$controller/change_password") ?>" class="login-form" id="forma">
                    <div id="StaraSif" class="input-container">
                            <input type="password" class="input" name="oldpassword" placeholder="Stara lozinka">
                    </div>
                    <div id="NovaSif" class="input-container">
                            <input type="password"  class="input" name="newpassword" placeholder="Nova lozinka">
                    </div>
                    <div class="input-container" id="sifrapotvrda">
                            <input type="password" class="input" id="login-password1"  name="newpasswordcheck" placeholder="Potvrda lozinke">
                    </div>    
                    <input type="submit" class="button" name="login" value = "Promeni lozinku">
                </form>
            </div>
        </div>
    </div>
</body>
</html>