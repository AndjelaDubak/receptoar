<html>
    <head>
        <title>Receptoar</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link type="image/png" href="<?php echo base_url(); ?>/img/logo.png" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/dodatni.css?v=<?php echo time(); ?>">
    </head>
    <body>
        <div class="container-fluid noc">
            <div class="row">
                <div class="col-12 col-sm-8 prviNoc">
                    <div class="pravila-header">
                        <img src="<?php echo base_url(); ?>/img/logo.png" height="70" width="80">
                        <h3 id="pravila">Pravila takmičenja</h3>
                    </div>
                    <div class="pravila" id="p1">
                        <ul>
                            <li>Možete da se predstavite sa jednim ili više recepata na zadatu temu i da glasate za recepte koji Vam se sviđaju</li>
                            <li>Takmičenje traje do zadatog datuma, kada se za pobednički bira recept sa najvećim brojem glasova</li>
                        </ul>
                        Sankcionisane zabranom učešća na takmičenju biće recepti koji sadrže:
                        <br>
                        <ul>
                            <li>eksplicitan, nasilan i drugi neprikladan sadržaj;</li>
                            <li>versku, etničku ili rasnu konotaciju;</li>
                            <li>uvredljiv sadržaj i govor mržnje;</li>
                            <li>sadržaj koji narušava ili krši prava drugih osoba, uključujući, ali ne
                                ograničavajući se samo na autorska prava i recepte osoba bez neophodne
                                saglasnosti sa njihove strane;
                            </li>
                            <li>sadržaj koji promoviše bilo kakav politički program ili poruku;</li>
                            <li>bilo koji oblik lične identifikacije (npr. adrese elektronske pošte, lična
                                imena, registarske tablice i dr).
                            </li>
                        </ul>
                    </div>
                    <a href="javascript:history.back()"><button class="buttonPravila">NAZAD</button></a>
                 
                </div>
            </div>
        </div>
    </body>
</html>