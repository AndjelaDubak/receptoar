<!--Autor: Aleksandar Dopudja 18/0118-->
<html>
    
     <?php
        $this->session= \Config\Services::session();
        $korisnik=$this->session->get('korisnik');
        if ($korisnik!=null) {
            $username = $korisnik[0]->Korisnicko_ime;
            $name = $korisnik[0]->Ime;
        } else {
            echo view('stranice/login_form');
        }
    ?>
	<head>
            <title>Receptoar</title>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <link type="image/png" href="<?php echo base_url(); ?>/img/logo1.png" rel="shortcut icon">
            <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.css">
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	</head>
        <body>
            <div id="wrapper">
                <div id="headerNoc">
                    <div id="logo">
                            <center><a href="<?php echo base_url(); ?>/Administrator/index_night"><img id="logoSlika" src="<?php echo base_url(); ?>/img/logo1.png"></a></center>
                    </div>
                    <div id="name">
                            <h1>RECEPTOAR</h1>
                    </div>
                    <div id="change">
                        <table >
                            <tr>
                                <td><a href="<?php echo base_url(); ?>/Administrator/index"><img id="rezimN" src="<?php echo base_url(); ?>/img/dan.png"></a></td>
                            </tr>
                        </table>
                    </div>
                </div>
                    <div id="mainNoc">
                        <div class="all">
                            <?php 
                                echo "<h2 id='tema'>$temaIme</h2>";
                                    $i=0;
                                    if(count($objave)){
                                        foreach ($objave as $obj){
                                            echo "<div class='single-itemNoc'>";
                                            echo "<div class='zaglavlje'>";
                                            echo "<a href='/receptoar/public/Administrator/lajkovanjeSlike?Id=".$obj->ID_objava."'><img src='/receptoar/public/img/korisnik_noc.png'></a>";
                                            echo '<h1>'.$korisnici[$i][0]->Korisnicko_ime.'</h1>';
                                            echo '</div>';
                                            $adr = $obj->Fotografija;                                                              
                                            echo "<a href='/receptoar/public/Administrator/ucitajRecept/$obj->ID_objava'><img src=".$adr." id='post'></a>";
                                            echo '<div class="meta">';

                                            //print_r(array_search($obj->ID_objava,$glasovi));
                                            if(array_search($obj->ID_objava,$glasovi)!=null){
                                                echo "<img id ='like' name='like$i' src ='/receptoar/public/img/like1.png' >";
                                            }
                                            else{
                                                echo "<img id ='like' name='like$i' src ='/receptoar/public/img/like_noc.png' onclick="."document.getElementsByName("."'like$i'".")"."[0].src='/receptoar/public/img/like1.png';f(".$obj->ID_objava.")".">";
                                            }

                                            echo "<a id = 'komentari' href='/receptoar/public/Administrator/ucitajKomentare/$obj->ID_objava'><img id='comment' src = '/receptoar/public/img/kom_noc.png'"." ></a>";
                                            echo '</div>';
                                            echo '</div>';
                                            $i++;
                                        }
                                    }
                                    else {
                                        echo "Nema slicica da se bache!";
                                    }
                            ?>

                            <script>
                                //var i= "<?php echo"$i"?>";
                                function f(id){
                                    //alert(id);
                                    //var ab = "abc";
                                    $.ajax({
                                        type: 'post',
                                        url: "<?php echo base_url(); ?>/Administrator/lajkovanjeSlike",
                                        data: {ID: id},
                                        datatype:'json',
                                        success: function (data) {
                                            //alert("sent");
                                        },
                                        error: function (request, status, error) {
                                            alert(request, status);
                                        }
                                    });


                                }
                            </script>
                        </div>
                    </div>
                    <div id="menu">
                        <ul>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_change_password_night" id="sifra">&nbsp;Promena lozinke&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_regulations_night" id="pravila">&nbsp;Pravila takmičenja&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_upload_form_night" id="postavljanje">&nbsp;Postavljanje recepta&nbsp;<a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/sortiranaVremeNoc" id="hronoloski">&nbsp;Sortiraj hronološki&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/sortiranaGlasNoc"  id="glasovi">&nbsp;Sortiraj po broju glasova&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/pobednickiNoc" id="pobednici">&nbsp;Pobednički recepti&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/listaKorisnikaNoc" id="korisnici">&nbsp;Spisak korisnika&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/listaModeratoraNoc" id="korisnici">&nbsp;Spisak moderatora&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/show_change_topic_night" id="tema">&nbsp;Promeni temu&nbsp;</a></li>
                            <hr>
                            <li><a href="<?php echo base_url(); ?>/Administrator/logoutNight" id="odjava">&nbsp;Odjava&nbsp;</a></li>
                            <hr>
                        </ul>
                    </div>
            </div>
	</body>
</html>
