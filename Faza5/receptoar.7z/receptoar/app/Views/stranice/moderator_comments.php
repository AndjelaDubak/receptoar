<!--Autor: Andjela Dubak 18/0658-->
<!DOCTYPE html>
<html lang="en">
    <?php
        $this->session= \Config\Services::session();
        $korisnik=$this->session->get('korisnik');
        if ($korisnik!=null) {
            $username = $korisnik[0]->Korisnicko_ime;
            $name = $korisnik[0]->Ime;
        } else {
            echo view('stranice/login_form');
        }
    ?>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptoar</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link type="image/png" href="<?php echo base_url(); ?>/img/logo1.png" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/dodatni.css">
</head>
<body>
    <div class="background">
        <h1></h1>
    </div>
    <div class="komentari-container">
        <div class="komentari-header">
            <h3 id="naslov"></h3>
        </div>
        
        <?php
            echo "<div id="."comments".">";
            if(count($komentari)){
                $i=0;
                foreach ($komentari as $kom){
                    echo "<div class="."single-comment".">";
                    echo "<img id="."user"." src="."/receptoar/public/img/user.png".">";

                    echo "<div class="."tekst".">";
                    echo "<font id="."komentar".">".$kom->Tekst."</font>";
                    echo "</div>";


                    if(in_array($kom->ID_komentar,$glasovi)==true){
                        echo "<img id='like' name='like$i' src='/receptoar/public/img/like1.png'>";
                    }
                    else{
                    echo "<img id='like' name='like$i' src='/receptoar/public/img/like.jpg' onclick="."document.getElementsByName("."'like$i'".")"."[0].src='/receptoar/public/img/like1.png';ff(".$kom->ID_komentar.")".">";
                    }
                    echo "<img class='trash' src='/receptoar/public/img/delete.jpg' onclick="."fff(".$kom->ID_komentar.",".$kom->ID_objava.")".">";
                     echo "</div>";
                     $i++;
                }
            }
        
       
            echo "<div id='write-comment'>";
            echo "<font id='unosKom'>";
            echo  "Unesite Vaš komentar: &nbsp;";
            echo "</font>";
            echo "<textarea id='tekst' name='' rows='2' cols='80'></textarea>";
            echo "<input type='submit' id='dugme' name='login' value = 'Posalji' onclick=f(".$komentari[0]->ID_objava.")>";
            echo "</div>";
        ?>
    </div>
    
    <script>
                                               
        function f(id){
            //alert(id);
            //var ab = "abc";
           tx= document.getElementById("tekst").value;
           //alert(tx);
            $.ajax({
                type: 'post',
                url: "<?php echo base_url(); ?>/Moderator/upisiKomentar",
                data: {ID: id, text:tx},
                datatype:'json',
                success: function (data) {
                    //alert("sent");
                    window.location="<?php echo base_url(); ?>/Moderator/ucitajKomentare/"+id;
                },
                error: function (request, status, error) {
                    alert(request, status);
                }
            });


        }

         function ff(id){
            //alert(id);

            $.ajax({
                type: 'post',
                url: "<?php echo base_url(); ?>/Moderator/upisLajka",
                data: {ID: id},
                datatype:'json',
                success: function (data) {
                    alert("sent");
                },
                error: function (request, status, error) {
                   // alert(request, status);
                }
            });


        }

        function fff(id,idObj){
            //alert(id);

            $.ajax({
                type: 'post',
                url: "<?php echo base_url(); ?>/Moderator/obrisiKomentar",
                data: {ID: id},
                datatype:'json',
                success: function (data) {
                    //alert("sent");
                    window.location="<?php echo base_url(); ?>/Moderator/ucitajKomentare/"+idObj;
                },
                error: function (request, status, error) {
                   // alert(request, status);
                }
            });


        }

    </script>
</body>
</html>