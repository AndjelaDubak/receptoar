<!--Autor: Aleksandar Dopudja 18/0118-->
<html>
    
     <?php
        $this->session= \Config\Services::session();
        $korisnik=$this->session->get('korisnik');
        if ($korisnik!=null) {
            $username = $korisnik[0]->Korisnicko_ime;
            $name = $korisnik[0]->Ime;
        } else {
            echo view('stranice/login_form');
        }
    ?>
     
<head>
    <title>Receptoar</title>
    <link type="image/png" href="<?php echo base_url(); ?>/img/logo1.png" rel="shortcut icon">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/css/style.css">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <script type="text/javascript" src="<?php echo base_url(); ?>/js/jezik.js"></script>
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <div id="logo">
                <center><a href="<?php echo base_url(); ?>/User"><img id="logoSlika" src="<?php echo base_url(); ?>/img/logo1.png"></a></center>
            </div>
            <div id="name">
                <h1>RECEPTOAR</h1>
            </div>
            <div id="change">
                <table >
                    <tr>

                    </tr>
                </table>
            </div>
        </div>
        <div id="main1">
            <div class="all">


                <?php
                    echo "<h2 id='tema'></h2>";
                    echo "<div class='single-item'>";
                        echo "<div class='zaglavlje'>";
                            echo "<img src='/receptoar/public/img/korisnik.png'>";
                            echo "<h1>".$korisnickoIme."</h1>";
                        echo "</div>";   
                            echo "<img src=".$objava->Fotografija." id = 'post'>";

                        echo "<div>";
                         echo "<h3 >Sastojci:</h3>";
                         echo "<ul id='lista'> ";

                        $sastojci=explode(',',$objava->Sastojci);

                        foreach($sastojci as $sas){
                            echo "<li>".$sas."</li>";
                        }
                        echo "</ul>";
                        echo "<h3>Opis:</h3>";
                        ////dodati nopis
                        echo $objava->Opis;
                        echo "</div>";

                        echo "<div class='meta'>";

                            if(array_search($objava->ID_objava,$glasovi)!=null){
                                 echo "<img id = 'like' src = '/receptoar/public/img/like1.png'>";
                            }
                            else{
                                echo "<img id ='like' name='like' src ='/receptoar/public/img/like.jpg' onclick="."document.getElementsByName("."'like'".")"."[0].src='/receptoar/public/img/like1.png';f(".$objava->ID_objava.")".">";
                            }
                            echo "<a id = 'komentari' href='/receptoar/public/User/ucitajKomentare/$objava->ID_objava'><img id='comment' src = '/receptoar/public/img/comment.jpg'>";
                        echo "</div>";  
                        echo "</div>";

                ?>

                <script>

                    function f(id){
                        alert(id);
                        //var ab = "abc";
                        $.ajax({
                            type: 'post',
                            url: "<?php echo base_url(); ?>/User/lajkovanjeSlike",
                            data: {ID: id},
                            datatype:'json',
                            success: function (data) {
                                alert("sent");
                            },
                            error: function (request, status, error) {
                                alert(request, status);
                            }
                        });                     

                    }


                </script>

            </div>
        </div>
    </div>
</body>
</html>

