<html>
    <head>
        <title>Receptoar</title>
        <link type="image/png" href="<?php echo base_url(); ?>/img/logo.png" rel="shortcut icon">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/css/dodatni.css">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    </head>
    <body>
        <div class="backgroundTopic">
            <div id="login">
                <div class="login-form-container" id="login-form">
                    <div class="login-form-content">
                        <div class="login-form-header">
                            <div class="logo">
                                <img src="<?php echo base_url(); ?>/img/logo.png" height="80" width="100">
                            </div>
                            <h3 id="pl">Dodavanje teme</h3>
                        </div>
                        <font color='red'>
                            <?php
                                if (isset($messages['message'])) {
                                    echo $messages['message'];
                                    unset($messages['message']);
                                }
                                if (isset($messages['topic'])) {
                                    echo "<br>-";
                                    echo $messages['topic'];
                                    unset($messages['topic']);
                                }
                            ?>
                        </font>
                        <form method="post" action="<?php echo site_url("$controller/change_topic") ?>" class="login-form" id="for">	
                            <div id="StaraSif" class="input-container">
                                <input type="text" class="input" name="topic" placeholder="Nova tema">
                            </div>
                            <input type="submit" class="button" name="changetopic" value = "Postavi temu">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>

