<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

/**
 * Klasa sa implementacijama funkcija za filtriranje stranice administratora
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class AdministratorFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null) {
       $session = session();
       $kor = $session->get('korisnik');
       if($kor == null || (($kor != null) && ($kor[0]->Kategorija_korisnika != 'A'))) {
           return redirect()->to(site_url('User_Authentication/index'));
       }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null) {
        // Do something here
    }
}


