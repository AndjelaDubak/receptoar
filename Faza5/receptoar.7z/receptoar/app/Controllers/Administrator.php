<?php

namespace App\Controllers;
use App\Models\login_database;
use App\Models\objava_database;
use App\Models\topic_database;

/**
 * Klasa sa implementacijama funkcija za realizaciju funkcionalnosti za administratora
 * Andjela Dubak 18/0658, Aleksandar Dopudja 18/0118
 */
class Administrator extends BaseController {
    
    /**
     * Funkcija za promenu lozinke
     * @return void
     */
    public function show_change_password() {
        // VIDETI PONOVO!!!!!
        echo view('stranice/change_password_form', ['controller' => 'administrator']);
    }
    
    /**
     * Funkcija za promenu lozinke u nocnom rezimu
     * @return void
     */
    public function show_change_password_night() {
        // VIDETI PONOVO!!!!!   
        echo view('stranice/change_password_form_night', ['controller' => 'administrator']);
    }
    
    /**
     * Funkcija za prikaz pravila
     * @return void
     */
    public function show_regulations() { 
        echo view('stranice/contest_regulations');
    }
    
    /**
     * Funkcija za prikaz pravila u nocnom rezimu
     * @return void
     */
    public function show_regulations_night() {
        echo view('stranice/contest_regulations_night');
    }
    
    /**
     * Funkcija za promenu teme
     * @return void
     */
    public function show_change_topic() {
        echo view('stranice/change_topic_form', ['controller' => 'administrator']);
    }
    
    /**
     * Funkcija za promenu teme u nocnom rezimu
     * @return void
     */
    public function show_change_topic_night() {
        echo view('stranice/change_topic_form_night', ['controller' => 'administrator']);
    }
    
    /**
     * Funkcija za prikaz stranice za dodavanje recepta
     * @return void
     */
    public function show_upload_form() {
        echo view('stranice/upload_photo_form', ['controller' => 'administrator']);
    }
    
    /**
     * Funkcija za prikaz stranice za dodavanje recepta u nocnom rezimu
     * @return void
     */
    public function show_upload_form_night() {
        echo view('stranice/upload_photo_form_night', ['controller' => 'administrator']);
    }
    
    /**
     * Funkcija za odjavljivanje
     * @return void
     */
    public function logout() {
        $this->session->destroy();
        $this->session->set('korisnik', null);
        print_r($this->session->get('korisnik'));
        echo view('stranice/login_form');
    }
    
    /**
     * Funkcija za odjavljivanje u nocnom rezimu
     * @return void
     */
    public function logoutNight() {
        $this->session->destroy();
        $this->session->set('korisnik', null);
        print_r($this->session->get('korisnik'));
        echo view('stranice/login_form_night');
    }
    
    /**
     * Funkcija za prikaz stranice za promenu lozinke
     * @return void
     */
     public function change_password() {
        $messages = [];
        //echo view('stranice/change_password_form', ['controller' => 'user']);
        
        $old_pass = $this->request->getVar('oldpassword');
        $new_pass = $this->request->getVar('newpassword');
        $new_pass_check = $this->request->getVar('newpasswordcheck');
        
        if(!$this->validate([
            'oldpassword' => 'required'
        ])&& $old_pass == null) {
            $messages['old_pass'] = 'stara lozinka';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'newpassword' => 'required'
        ]) && $new_pass == null) {
            $messages['new_pass'] = 'nova lozinka';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'newpasswordcheck' => 'required'
        ])&& $new_pass_check == null) {
            $messages['new_pass_check'] = 'potvrda nove lozinke';
            $messages['message'] = 'Obavezno:';
        }
        if(strlen($new_pass_check) < 8 && $new_pass != null) {
            $messages['passLen'] = 'Lozinka mora sadržati minimum 8 karaktera!';
        }
        if(strlen($new_pass_check) < 8 && $new_pass_check != null) {
            $messages['newpasscheckLen'] = 'Potvrda nove lozinke mora sadržati minimum 8 karaktera!';
        }
        
        if($old_pass != null) {
           // $this->session->destroy();
            $korisnik = $this->session->get('korisnik');
           // print_r($korisnik);
            if($korisnik[0]->Lozinka != $old_pass) {
                $messages['messageOld'] = "Stara lozinka nije ispravna!";
            }
            else {
                if($new_pass != $new_pass_check) {
                    $messages['newpasswordDifferent'] = "Potvrda lozinke nije ista kao lozinka!";
                }
                else {
                    $loginDatabaseModel = new Login_Database();
                   // $kor = $loginDatabaseModel->find($korisnik[0]->ID_korisnik);
                    $korisnik[0]->Lozinka = "";
                    $korisnik[0]->Lozinka = $new_pass;
                    //print_r($korisnik);
                    $loginDatabaseModel->update($korisnik[0]->ID_korisnik, $korisnik[0]);
                    $this->session->set('korisnik', null);
                    echo view('stranice/login_form');
                }
            }
        } 
        
        //print_r($current);
        if ($messages != []) {
            echo view('stranice/change_password_form', ['controller' => 'administrator', 'messages' => $messages]);
        }
    }
    
    /**
     * Funkcija za prikaz stranice za promenu lozinke u nocnom rezimu
     * @return void
     */
    public function change_password_night() {
        $messages = [];
        //echo view('stranice/change_password_form', ['controller' => 'user']);
        
        $old_pass = $this->request->getVar('oldpassword');
        $new_pass = $this->request->getVar('newpassword');
        $new_pass_check = $this->request->getVar('newpasswordcheck');
        
        if(!$this->validate([
            'oldpassword' => 'required'
        ])&& $old_pass == null) {
            $messages['old_pass'] = 'stara lozinka';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'newpassword' => 'required'
        ]) && $new_pass == null) {
            $messages['new_pass'] = 'nova lozinka';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'newpasswordcheck' => 'required'
        ])&& $new_pass_check == null) {
            $messages['new_pass_check'] = 'potvrda nove lozinke';
            $messages['message'] = 'Obavezno:';
        }
        if(strlen($new_pass_check) < 8 && $new_pass != null) {
            $messages['passLen'] = 'Lozinka mora sadržati minimum 8 karaktera!';
        }
        if(strlen($new_pass_check) < 8 && $new_pass_check != null) {
            $messages['newpasscheckLen'] = 'Potvrda nove lozinke mora sadržati minimum 8 karaktera!';
        }
        
        if($old_pass != null) {
           // $this->session->destroy();
            $korisnik = $this->session->get('korisnik');
           // print_r($korisnik);
            if($korisnik[0]->Lozinka != $old_pass) {
                $messages['messageOld'] = "Stara lozinka nije ispravna!";
            }
            else {
                if($new_pass != $new_pass_check) {
                    $messages['newpasswordDifferent'] = "Potvrda lozinke nije ista kao lozinka!";
                }
                else {
                    $loginDatabaseModel = new Login_Database();
                   // $kor = $loginDatabaseModel->find($korisnik[0]->ID_korisnik);
                    $korisnik[0]->Lozinka = "";
                    $korisnik[0]->Lozinka = $new_pass;
                    //print_r($korisnik);
                    $loginDatabaseModel->update($korisnik[0]->ID_korisnik, $korisnik[0]);
                    $this->session->set('korisnik', null);
                    echo view('stranice/login_form_night');
                }
            }
        } 
        
        //print_r($current);
        if ($messages != []) {
            echo view('stranice/change_password_form_night', ['controller' => 'administrator', 'messages' => $messages]);
        }
    }
    
    /**
     * Funkcija za ucitavanje recepta i provera unetih informacija
     * @return void
     */
    public function uploadPic() {
        $messages = [];
        
        $naziv = $this->request->getVar('name');
        $opis = $this->request->getVar('opis');
        $sastojci = $this->request->getVar('sastojci');
        
        if(!$this->validate([
            'name' => 'required'
        ])) {
            $messages['name'] = 'naziv recepta';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'opis' => 'required'
        ])) {
            $messages['opis'] = 'opis recepta';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'sastojci' => 'required'
        ])) {
            $messages['sastojci'] = 'sastojci';
            $messages['message'] = 'Obavezno:';
        }
        
        if($messages != []) {
            return view('stranice/upload_photo_form', ['controller' => 'administrator', 'messages' => $messages]);
        }
        
        $input = $this->validate([
           'file' => 'uploaded[file]|ext_in[file,png,jpg]'
        ]);
        
        if (!$input) { // Not valid
            $messages['message'] = 'Greska u ubacivanju fotografije'; 
            return view('stranice/upload_photo_form', ['controller' => 'administrator', 'messages' => $messages]); 
        }
        else { // Valid
            if($file = $this->request->getFile('file')) {
               if ($file->isValid() && ! $file->hasMoved()) {
                  // Get file name and extension
                  $name = $file->getName();
                  $ext = $file->getClientExtension(); 

                  $filepath = base_url()."/uploads/".$name;
                  
                  // Store file in public/uploads/ folder
                  $file->move('../public/uploads', $name);
                  $korisnik = $this->session->get('korisnik');
                  
                  print_r($korisnik);
                  
                  $objavaDatabase = new Objava_Database();
                  $objavaDatabase->insertImage($filepath, $korisnik, $naziv, $opis, $sastojci);
  
                }
                else{
                    $messages['message'] = 'Slika nije ubacena';
                    return view('stranice/upload_photo_form', ['controller' => 'administrator', 'messages' => $messages]); 
                }
            }
        }
        
        return redirect()->to(site_url('Administrator'));
    }
    
    /**
     * Funkcija za ucitavanje recepta i provera unetih informacija u nocnom rezimu
     * @return void
     */
    public function uploadPicNight() {
        $messages = [];
        
        $naziv = $this->request->getVar('name');
        $opis = $this->request->getVar('opis');
        $sastojci = $this->request->getVar('sastojci');
        
        if(!$this->validate([
            'name' => 'required'
        ])) {
            $messages['name'] = 'naziv recepta';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'opis' => 'required'
        ])) {
            $messages['opis'] = 'opis recepta';
            $messages['message'] = 'Obavezno:';
        }
        if(!$this->validate([
            'sastojci' => 'required'
        ])) {
            $messages['sastojci'] = 'sastojci';
            $messages['message'] = 'Obavezno:';
        }
        
        if($messages != []) {
            return view('stranice/upload_photo_form_night', ['controller' => 'administrator', 'messages' => $messages]);
        }
        
        $input = $this->validate([
           'file' => 'uploaded[file]|ext_in[file,png,jpg]'
        ]);
        
        if (!$input) { // Not valid
            $messages['message'] = 'Greska u ubacivanju fotografije'; 
            return view('stranice/upload_photo_form_night', ['controller' => 'administrator', 'messages' => $messages]); 
        }
        else { // Valid
            if($file = $this->request->getFile('file')) {
               if ($file->isValid() && ! $file->hasMoved()) {
                  // Get file name and extension
                  $name = $file->getName();
                  $ext = $file->getClientExtension(); 

                  $filepath = base_url()."/uploads/".$name;
                  
                  // Store file in public/uploads/ folder
                  $file->move('../public/uploads', $name);
                  $korisnik = $this->session->get('korisnik');
                  
                  print_r($korisnik);
                  
                  $objavaDatabase = new Objava_Database();
                  $objavaDatabase->insertImage($filepath, $korisnik, $naziv, $opis, $sastojci);
  
                }
                else{
                    $messages['message'] = 'Slika nije ubacena';
                    return view('stranice/upload_photo_form_night', ['controller' => 'administrator', 'messages' => $messages]); 
                }
            }
        }
        
        return redirect()->to(site_url('Administrator/index_night'));
    }
    
    /**
     * Funkcija za prikaz glavne stranice administratora
     * @return void
     */
    public function index(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getObjave();
        
        $topicDatabase=new \App\Models\Topic_Database();
        $tema=$topicDatabase->current_topic();
        
        $new=$topicDatabase->where('ID_tema', $tema)->findAll();
        $temaIme = $new[0]->Naziv;
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/administrator_page',['objave'=>$objave,'temaIme'=>$temaIme,'korisnici'=>$niz,'glasovi'=>$niz2]);
        
    }
    
    /**
     * Funkcija za prikaz glavne stranice administratora u nocnom rezimu
     * @return void
     */
    public function index_night(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getObjave();
        
        $topicDatabase=new \App\Models\Topic_Database();
        $tema=$topicDatabase->current_topic();
        
        $new=$topicDatabase->where('ID_tema', $tema)->findAll();
        $temaIme = $new[0]->Naziv;
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/administrator_page_night',['objave'=>$objave,'temaIme'=>$temaIme,'korisnici'=>$niz,'glasovi'=>$niz2]);
        
    }
    
    /**
     * Funkcija za prikaz svih korisnika
     * @return void
     */
    public function listaKorisnika() {
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisnici = $korisniciDatabase->getSveKorisnike();
        
        echo view('stranice/adm_list_of_users',['list'=>$korisnici]);
    }
    
    /**
     * Funkcija za prikaz svih korisnika u nocnom rezimu
     * @return void
     */
    public function listaKorisnikaNoc() {
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisnici = $korisniciDatabase->getSveKorisnike();
        
        echo view('stranice/adm_list_of_users_night',['list'=>$korisnici]);
    }
    
    /**
     * Funkcija za prikaz svih moderaotora
     * @return void
     */
    public function listaModeratora() {
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisnici = $korisniciDatabase->getSveModeratore();
        
        echo view('stranice/adm_list_of_moderators',['list'=>$korisnici]);
    }
    
    /**
     * Funkcija za prikaz svih moderatora u nocnom rezimu
     * @return void
     */
    public function listaModeratoraNoc() {
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisnici = $korisniciDatabase->getSveModeratore();
        
        echo view('stranice/adm_list_of_moderators_night',['list'=>$korisnici]);
    }
    
    /**
     * Funkcija za unapredjenje korisnika u moderatora ili moderatora u administartora
     * @return void 
     */
    public function upgrade_account($korIme) {
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisniciDatabase->promeniKategoriju($korIme);
        return redirect()->to(site_url('Administrator/listaKorisnika'));
    }
    
    /**
     * Funkcija za unapredjenje korisnika u moderatora ili moderatora u administratora u nocnom rezimu
     * @return void
     */
    public function upgrade_account_night($korIme) {
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisniciDatabase->promeniKategoriju($korIme);
        return redirect()->to(site_url('Administrator/listaKorisnikaNoc'));
    }
    
    /**
     * Funkcija za brisanje korisnika
     * @return void
     */
    public function delete_account($korIme) {
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisniciDatabase->obrisiKorisnika($korIme);
        return redirect()->to(site_url('Administrator/listaKorisnika'));
    }
    
    /**
     * Funkcija za brisanje korisnika u nocnom rezimu
     * @return void
     */
    public function delete_account_night($korIme) {
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisniciDatabase->obrisiKorisnika($korIme);
        return redirect()->to(site_url('Administrator/listaKorisnikaNoc'));
    }
    
    /**
     * Funkcija za pretvaranje moderatora u korisnika
     * @return void
     */
    public function downgrade_account($korIme) {
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisniciDatabase->promeniKategoriju($korIme);
        return redirect()->to(site_url('Administrator/listaModeratora'));
    }
    
    /**
     * Funkcija za pretvaranje moderatora u korisnikau nocnom rezimu
     * @return void
     */
    public function downgrade_account_night($korIme) {
        $korisniciDatabase=new \App\Models\Login_Database();
        $korisniciDatabase->promeniKategoriju($korIme);
        return redirect()->to(site_url('Administrator/listaModeratoraNoc'));
    }
    
    /**
     * Funkcija za prikaz sortiranih recepata po glasovima
     * @return void
     */
    public function sortiranaGlas(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getSortiraneGlas();
        
        $topicDatabase=new \App\Models\Topic_Database();
        $tema=$topicDatabase->current_topic();
        
        $new=$topicDatabase->where('ID_tema', $tema)->findAll();
        $temaIme = $new[0]->Naziv;
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/administrator_page',['objave'=>$objave,'temaIme'=>$temaIme,'korisnici'=>$niz,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za prikaz sortiranih recepata po glasovima u nocnom rezimu
     * @return void
     */
    public function sortiranaGlasNoc(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getSortiraneGlas();
        
        $topicDatabase=new \App\Models\Topic_Database();
        $tema=$topicDatabase->current_topic();
        
        $new=$topicDatabase->where('ID_tema', $tema)->findAll();
        $temaIme = $new[0]->Naziv;
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/administrator_page_night',['objave'=>$objave,'temaIme'=>$temaIme,'korisnici'=>$niz,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za prikaz sortiranih recepata po vremenu
     * @return void
     */
    public function sortiranaVreme(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getSortiraneVreme();
        
        $topicDatabase=new \App\Models\Topic_Database();
        $tema=$topicDatabase->current_topic();
        
        $new=$topicDatabase->where('ID_tema', $tema)->findAll();
        $temaIme = $new[0]->Naziv;
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/administrator_page',['objave'=>$objave,'temaIme'=>$temaIme,'korisnici'=>$niz,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za prikaz sortiranih recepata po vremenu u nocnom rezimu
     * @return void
     */
    public function sortiranaVremeNoc(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getSortiraneVreme();
        
        $topicDatabase=new \App\Models\Topic_Database();
        $tema=$topicDatabase->current_topic();
        
        $new=$topicDatabase->where('ID_tema', $tema)->findAll();
        $temaIme = $new[0]->Naziv;
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/administrator_page_night',['objave'=>$objave,'temaIme'=>$temaIme,'korisnici'=>$niz,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za prikaz pobednickih recepata
     * @return void
     */
    public function pobednicki(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getPobednicke();
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/adm_winning_rec',['objave'=>$objave,'korisnici'=>$niz,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za prikaz sortiranih recepata u nocnom rezimu
     * @return void
     */
    public function pobednickiNoc(){
        
        $objaveDatabase=new \App\Models\Objava_Database();
        $objave=$objaveDatabase->getPobednicke();
        
        $korisniciDatabase=new \App\Models\Login_Database();
        $niz=array();
        foreach ($objave as $obj){
            array_push($niz,$korisniciDatabase->getKorisnik($obj->ID_korisnik));
        }
        
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
        
        if($this->session->get('korisnik')==null)print_r("Nema");
        echo view('stranice/adm_winning_rec_night',['objave'=>$objave,'korisnici'=>$niz,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za prikaz stranice za promenu temu
     * @return void
     */
    public function change_topic() {
        $messages = [];
        $top = $this->request->getVar('topic');
        $topic = array(
                'Naziv' => $top,
                'Aktuelna' => 2,
                'Vreme' => /* time() + 60 */ strtotime('next monday'));
        if(!$this->validate([
            'topic' => 'required'
        ])) {
            $messages['topic'] = 'naziv teme';
            $messages['message'] = 'Obavezno:';
            echo view('stranice/change_topic_form', ['controller' => 'administrator', 'messages' => $messages]);
        }
        else {
            $topicDatabaseModel = new Topic_Database();
            $topicOld = $topicDatabaseModel->where('Aktuelna', 2)->findAll();
            $topicOldArray = array(
                'ID_tema' => $topicOld[0]->ID_tema,
                'Naziv' => $topicOld[0]->Naziv,
                'Aktuelna' => 3,
                'Vreme' => $topicOld[0]->Vreme);
            print_r($topicOld);
            $topicDatabaseModel->update($topicOld[0]->ID_tema, $topicOldArray);
            $topicDatabaseModel->insert($topic);
            //PROMENITI u index
            return redirect()->to(site_url('Administrator'));
        }
    }
    
    /**
     * Funkcija za prikaz stranice za promenu teme u nocnom rezimu
     * @return void
     */
    public function change_topic_night() {
        $messages = [];
        $top = $this->request->getVar('topic');
        $topic = array(
                'Naziv' => $top,
                'Aktuelna' => 2,
                'Vreme' => /* time() + 60 */ strtotime('next monday'));
        if(!$this->validate([
            'topic' => 'required'
        ])) {
            $messages['topic'] = 'naziv teme';
            $messages['message'] = 'Obavezno:';
            echo view('stranice/change_topic_form_night', ['controller' => 'administrator', 'messages' => $messages]);
        }
        else {
            $topicDatabaseModel = new Topic_Database();
            $topicOld = $topicDatabaseModel->where('Aktuelna', 2)->findAll();
            $topicOldArray = array(
                'ID_tema' => $topicOld[0]->ID_tema,
                'Naziv' => $topicOld[0]->Naziv,
                'Aktuelna' => 3,
                'Vreme' => $topicOld[0]->Vreme);
            print_r($topicOld);
            $topicDatabaseModel->update($topicOld[0]->ID_tema, $topicOldArray);
            $topicDatabaseModel->insert($topic);
            //PROMENITI u index
            return redirect()->to(site_url('Administrator/index_night'));
        }
    }
    
    /**
     * Funkcija za lajkovanje recepta
     * @return void
     */
    public function lajkovanjeSlike() {
        //print_r("USAO U FJU");
        $id= $this->request->getPost('ID');
        $objaveDatabase=new \App\Models\Objava_Database();
        $glasDatabase=new \App\Models\Glas_Database();
        if($glasDatabase->dajGlas($id)){
            $objaveDatabase->updateObjava($id);
        } 
    }
    
    /**
     * Funkcija za ucitavanje komentara
     * @return void
     */
    public function ucitajKomentare($id){
        $komentariDatabase=new \App\Models\Komentar_Database();
        $komentari=$komentariDatabase->getKomentare($id);
        
        $lajkoviDatabase=new \App\Models\Lajk_Database();
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $lajkovi=$lajkoviDatabase->getLajkovaneKomentare($idKor);
        $k=$komentariDatabase->getIDkomentara($id);
        
        foreach ($lajkovi as $lk){
           if(in_array($lk->ID_komentar,$k)==true)array_push($niz2,$lk->ID_komentar);
        }
        }
        
        echo view('stranice/user_comments',['komentari'=>$komentari,'glasovi'=>$niz2]);
    }
    
    /**
     * Funkcija za upisivanje komentara
     * @return void
     */
    public function upisiKomentar(){
       $id= $this->request->getPost('ID');
       $text = $this->request->getPost('text');
       
       $komentariDatabase=new \App\Models\Komentar_Database();
       $komentariDatabase->dodajKomentar($id, $text);
       
       $objaveDatabase=new \App\Models\Objava_Database();
       $objaveDatabase->povecajBrojKomentara($id);
    }
    
    /**
     * Funkcija za upis lajkova
     * @return void
     */
    public function upisLajka(){
        $id= $this->request->getPost('ID');
        $lajkoviDatabase=new \App\Models\Lajk_Database();
        
        //$komentariDatabase=new \App\Models\Komentar_Database();
        //$komentariDatabase->dodajLajk($id);
        
        $lajkoviDatabase->dodajLajk($id);
    }
    
    /**
     * Funkcija za ucitavanje recepta
     * @return void
     */
    public function ucitajRecept($id){
         $objaveDatabase=new \App\Models\Objava_Database();
         $objava=$objaveDatabase->getObjava($id);
         
         $korisniciDatabase=new \App\Models\Login_Database();
         $korisnik=$korisniciDatabase->getKorisnik($objava->ID_korisnik)[0];
         
         
        $glasoviDatabase=new \App\Models\Glas_Database;
        $niz2=array();
        array_push($niz2,-1);
        if($this->session->get('korisnik')!=null){
            $kor=$this->session->get('korisnik');
            $idKor=$kor[0]->ID_korisnik;
        $glasovi=$glasoviDatabase->getGlasove($idKor);
        foreach ($glasovi as $gl){
            if($gl->ID_korisnik==$idKor)array_push($niz2,$gl->ID_objava);
        }
        }
         
         echo view('stranice/recept_user',['objava'=>$objava,'korisnickoIme'=>$korisnik->Korisnicko_ime,'glasovi'=>$niz2]);
    }
    
    
    /**
     * Funkcija za ispisKomentara
     * @return void
     */
    public function ispisiKomentare($id){
        $komentariDatabase=new \App\Models\Komentar_Database();
        $komentari=$komentariDatabase->getKomentare($id);
        echo view('stranice/user_comments',['komentari'=>$komentari]);
    }
    
}
